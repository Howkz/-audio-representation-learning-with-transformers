# ASR Dataset Breakdown (5 seeds)

| Dataset | WER mean +- std |
|---|---|
| openslr/librispeech_asr:test.clean | 1.0000 +- 0.0000 |
